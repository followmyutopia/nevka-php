<?php
/**
 * Nevka PHP API v1.0
 * 2025 Avicus Delacroix
 * 
 * Creates a new user.
 * Accepts: email, password (multipart/form-data)
 * Returns: result, error? (json)
 */

if ($_POST['api-key'] == "qonxod-Kicmad-4puvhy") {
    date_default_timezone_set("Europe/Moscow");

    $token = $pushToken = "";

    function validate($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if (isset($_POST['email']) && isset($_POST['password'])) {
        $login = validate($_POST['email']);
        $password = validate($_POST['password']);
        $passwordHash = sha1($password);
        $newToken = "NevkaToken2.0[".$login."-".$passwordHash."]";

        include '../credentials.php';

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            echo "{\"result\":\"failure\",\"error\":\"Нет доступа к базе данных\"}";
        }

        $sql = "SELECT id FROM users WHERE login='$login' LIMIT 1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "{\"result\":\"failure\",\"error\":\"Пользователь с такой почтой уже существует\"}";
        } else {
            include '../defaultImage.php';
            $sql = "INSERT INTO users (login, password, token, avatar)
            VALUES ('$login', '$passwordHash', '$newToken', '$defaultImage')";

            if ($conn->query($sql) === TRUE) {
                echo "{\"result\":\"success\"}";
            } else {
                echo "{\"result\":\"failure\",\"error\":\"Ошибка записи в БД\"}";
            }
        }

        $conn->close();
    } else {
        echo "{\"result\":\"failure\",\"error\":\"Параметры email, password обязательны\"}";
    }
}
?>